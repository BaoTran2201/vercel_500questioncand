import { useState } from 'react';
import { questions } from '../data/questions';
import { Check, ChevronLeft, ChevronRight } from 'lucide-react';

export function StudyMode() {
  const [currentPage, setCurrentPage] = useState(1);
  const questionsPerPage = 10;
  const totalPages = Math.ceil(questions.length / questionsPerPage);

  const startIndex = (currentPage - 1) * questionsPerPage;
  const endIndex = startIndex + questionsPerPage;
  const currentQuestions = questions.slice(startIndex, endIndex);

  const handlePreviousPage = () => {
    setCurrentPage((prev) => Math.max(prev - 1, 1));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNextPage = () => {
    setCurrentPage((prev) => Math.min(prev + 1, totalPages));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-green-100">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h2 className="text-green-800">Học bài</h2>
            <p className="text-gray-600">Học qua tất cả các câu hỏi trong bộ đề và xem câu trả lời đúng</p>
          </div>
          <div className="flex items-center space-x-2">
            <div className="bg-green-50 px-4 py-2 rounded-lg border border-green-200">
              <span className="text-green-700">
                Page {currentPage} of {totalPages}
              </span>
            </div>
            <div className="bg-gray-50 px-4 py-2 rounded-lg border border-gray-200">
              <span className="text-gray-700">
                Tổng: 750 câu
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Questions List */}
      <div className="grid gap-6">
        {currentQuestions.map((q) => (
          <div
            key={q.id}
            className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow duration-200 overflow-hidden border border-gray-100"
          >
            {/* Question Header */}
            <div className="bg-gradient-to-r from-green-50 to-green-100 px-6 py-4 border-b border-green-200">
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0 w-10 h-10 bg-green-500 text-white rounded-lg flex items-center justify-center">
                  {q.id}
                </div>
                <div className="flex-1">
                  <p className="text-gray-800">{q.question}</p>
                </div>
              </div>
            </div>

            {/* Answers */}
            <div className="p-6 space-y-3">
              {q.answers.map((answer, index) => {
                const isCorrect = index === q.correctAnswer;
                return (
                  <div
                    key={index}
                    className={`relative rounded-lg p-4 transition-all duration-200 ${
                      isCorrect
                        ? 'bg-green-50 border-2 border-green-500 shadow-sm'
                        : 'bg-gray-50 border border-gray-200'
                    }`}
                  >
                    <div className="flex items-start space-x-3">
                      <div
                        className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center ${
                          isCorrect
                            ? 'bg-green-500 text-white'
                            : 'bg-white border-2 border-gray-300'
                        }`}
                      >
                        {isCorrect ? (
                          <Check className="w-4 h-4" />
                        ) : (
                          <span className="text-xs text-gray-500">
                            {String.fromCharCode(65 + index)}
                          </span>
                        )}
                      </div>
                      <p
                        className={`flex-1 ${
                          isCorrect ? 'text-green-900' : 'text-gray-700'
                        }`}
                      >
                        {answer}
                      </p>
                    </div>
                    {isCorrect && (
                      <div className="absolute top-2 right-2">
                        <span className="inline-flex items-center px-2 py-1 rounded-md bg-green-500 text-white text-xs">
                          Correct Answer
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-center space-x-4 py-8">
        <button
          onClick={handlePreviousPage}
          disabled={currentPage === 1}
          className="flex items-center space-x-2 px-6 py-3 rounded-lg bg-white border border-gray-300 text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-sm hover:shadow"
        >
          <ChevronLeft className="w-5 h-5" />
          <span>Previous</span>
        </button>

        <div className="flex items-center space-x-2">
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
            <button
              key={page}
              onClick={() => {
                setCurrentPage(page);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`w-10 h-10 rounded-lg transition-all duration-200 ${
                page === currentPage
                  ? 'bg-green-500 text-white shadow-lg'
                  : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
              }`}
            >
              {page}
            </button>
          ))}
        </div>

        <button
          onClick={handleNextPage}
          disabled={currentPage === totalPages}
          className="flex items-center space-x-2 px-6 py-3 rounded-lg bg-white border border-gray-300 text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-sm hover:shadow"
        >
          <span>Next</span>
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
