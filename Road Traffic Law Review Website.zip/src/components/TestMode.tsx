import { useState } from 'react';
import { questions, Question } from '../data/questions';
import { Check, X, RotateCcw, Award } from 'lucide-react';

export function TestMode() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<(number | null)[]>(
    new Array(questions.length).fill(null)
  );
  const [showResults, setShowResults] = useState(false);

  const handleAnswerSelect = (answerIndex: number) => {
    if (showResults) return;
    
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleSubmit = () => {
    setShowResults(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleReset = () => {
    setCurrentQuestion(0);
    setSelectedAnswers(new Array(questions.length).fill(null));
    setShowResults(false);
  };

  const calculateScore = () => {
    let correct = 0;
    selectedAnswers.forEach((answer, index) => {
      if (answer === questions[index].correctAnswer) {
        correct++;
      }
    });
    return {
      correct,
      total: questions.length,
      percentage: Math.round((correct / questions.length) * 100),
    };
  };

  const score = calculateScore();
  const question = questions[currentQuestion];
  const answered = selectedAnswers.filter((a) => a !== null).length;

  if (showResults) {
    return (
      <div className="space-y-6">
        {/* Results Header */}
        <div className="bg-white rounded-xl shadow-lg p-8 border border-green-100">
          <div className="text-center space-y-4">
            <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto">
              <Award className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-green-800">Test Results</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6">
              <div className="bg-green-50 rounded-lg p-4 border border-green-200">
                <p className="text-gray-600 text-sm">Correct Answers</p>
                <p className="text-green-700">{score.correct}</p>
              </div>
              <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                <p className="text-gray-600 text-sm">Total Questions</p>
                <p className="text-blue-700">{score.total}</p>
              </div>
              <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
                <p className="text-gray-600 text-sm">Score</p>
                <p className="text-purple-700">{score.percentage}%</p>
              </div>
            </div>
            <button
              onClick={handleReset}
              className="flex items-center space-x-2 px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors duration-200 shadow-md mx-auto"
            >
              <RotateCcw className="w-5 h-5" />
              <span>Retake Test</span>
            </button>
          </div>
        </div>

        {/* Detailed Results */}
        <div className="space-y-4">
          <h3 className="text-gray-800">Answer Review</h3>
          {questions.map((q, qIndex) => {
            const userAnswer = selectedAnswers[qIndex];
            const isCorrect = userAnswer === q.correctAnswer;
            
            return (
              <div
                key={q.id}
                className={`bg-white rounded-xl shadow-sm overflow-hidden border ${
                  isCorrect ? 'border-green-200' : 'border-red-200'
                }`}
              >
                <div
                  className={`px-6 py-4 ${
                    isCorrect
                      ? 'bg-gradient-to-r from-green-50 to-green-100'
                      : 'bg-gradient-to-r from-red-50 to-red-100'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3 flex-1">
                      <div
                        className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center ${
                          isCorrect
                            ? 'bg-green-500 text-white'
                            : 'bg-red-500 text-white'
                        }`}
                      >
                        {q.id}
                      </div>
                      <p className="text-gray-800 flex-1">{q.question}</p>
                    </div>
                    <div
                      className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                        isCorrect ? 'bg-green-500' : 'bg-red-500'
                      }`}
                    >
                      {isCorrect ? (
                        <Check className="w-5 h-5 text-white" />
                      ) : (
                        <X className="w-5 h-5 text-white" />
                      )}
                    </div>
                  </div>
                </div>

                <div className="p-6 space-y-3">
                  {q.answers.map((answer, index) => {
                    const isUserAnswer = index === userAnswer;
                    const isCorrectAnswer = index === q.correctAnswer;

                    return (
                      <div
                        key={index}
                        className={`rounded-lg p-4 border-2 ${
                          isCorrectAnswer
                            ? 'bg-green-50 border-green-500'
                            : isUserAnswer
                            ? 'bg-red-50 border-red-500'
                            : 'bg-gray-50 border-gray-200'
                        }`}
                      >
                        <div className="flex items-start space-x-3">
                          <div
                            className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center ${
                              isCorrectAnswer
                                ? 'bg-green-500 text-white'
                                : isUserAnswer
                                ? 'bg-red-500 text-white'
                                : 'bg-white border-2 border-gray-300'
                            }`}
                          >
                            {isCorrectAnswer || isUserAnswer ? (
                              isCorrectAnswer ? (
                                <Check className="w-4 h-4" />
                              ) : (
                                <X className="w-4 h-4" />
                              )
                            ) : (
                              <span className="text-xs text-gray-500">
                                {String.fromCharCode(65 + index)}
                              </span>
                            )}
                          </div>
                          <p className="flex-1 text-gray-800">{answer}</p>
                          {isCorrectAnswer && (
                            <span className="text-xs px-2 py-1 bg-green-500 text-white rounded">
                              Correct
                            </span>
                          )}
                          {isUserAnswer && !isCorrectAnswer && (
                            <span className="text-xs px-2 py-1 bg-red-500 text-white rounded">
                              Your Answer
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Progress Header */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-green-100">
        <div className="space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h2 className="text-green-800">Trả bài</h2>
              <p className="text-gray-600">
                Câu hỏi {currentQuestion + 1} of {questions.length}
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <div className="bg-green-50 px-4 py-2 rounded-lg border border-green-200">
                <span className="text-green-700">
                  Trả lời: {answered}/{questions.length}
                </span>
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
            <div
              className="bg-gradient-to-r from-green-500 to-green-600 h-3 rounded-full transition-all duration-300"
              style={{
                width: `${((currentQuestion + 1) / questions.length) * 100}%`,
              }}
            />
          </div>
        </div>
      </div>

      {/* Question Card */}
      <div className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-100">
        {/* Question */}
        <div className="bg-gradient-to-r from-green-50 to-green-100 px-6 py-6 border-b border-green-200">
          <div className="flex items-start space-x-3">
            <div className="flex-shrink-0 w-12 h-12 bg-green-500 text-white rounded-lg flex items-center justify-center">
              {question.id}
            </div>
            <div className="flex-1">
              <p className="text-gray-800">{question.question}</p>
            </div>
          </div>
        </div>

        {/* Answers */}
        <div className="p-6 space-y-3">
          {question.answers.map((answer, index) => {
            const isSelected = selectedAnswers[currentQuestion] === index;
            return (
              <button
                key={index}
                onClick={() => handleAnswerSelect(index)}
                className={`w-full text-left rounded-lg p-4 transition-all duration-200 border-2 ${
                  isSelected
                    ? 'bg-green-50 border-green-500 shadow-md'
                    : 'bg-gray-50 border-gray-200 hover:border-green-300 hover:bg-green-50'
                }`}
              >
                <div className="flex items-start space-x-3">
                  <div
                    className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center border-2 ${
                      isSelected
                        ? 'bg-green-500 border-green-500 text-white'
                        : 'bg-white border-gray-300 text-gray-500'
                    }`}
                  >
                    {isSelected ? (
                      <Check className="w-4 h-4" />
                    ) : (
                      <span className="text-xs">
                        {String.fromCharCode(65 + index)}
                      </span>
                    )}
                  </div>
                  <p className={isSelected ? 'text-green-900' : 'text-gray-700'}>
                    {answer}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between gap-4">
        <button
          onClick={handlePrevious}
          disabled={currentQuestion === 0}
          className="px-6 py-3 rounded-lg bg-white border border-gray-300 text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-sm"
        >
          Previous
        </button>

        <div className="flex-1 flex justify-center">
          {currentQuestion === questions.length - 1 &&
            answered === questions.length && (
              <button
                onClick={handleSubmit}
                className="px-8 py-3 rounded-lg bg-gradient-to-r from-green-500 to-green-600 text-white hover:from-green-600 hover:to-green-700 transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                Submit Test
              </button>
            )}
        </div>

        <button
          onClick={handleNext}
          disabled={currentQuestion === questions.length - 1}
          className="px-6 py-3 rounded-lg bg-green-500 text-white hover:bg-green-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-sm"
        >
          Next
        </button>
      </div>

      {/* Question Grid Navigation */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <h3 className="text-gray-800 mb-4">Quick Navigation</h3>
        <div className="grid grid-cols-5 sm:grid-cols-10 md:grid-cols-15 lg:grid-cols-20 gap-2">
          {questions.map((q, index) => {
            const isAnswered = selectedAnswers[index] !== null;
            const isCurrent = index === currentQuestion;
            
            return (
              <button
                key={q.id}
                onClick={() => setCurrentQuestion(index)}
                className={`w-10 h-10 rounded-lg transition-all duration-200 ${
                  isCurrent
                    ? 'bg-green-500 text-white shadow-lg scale-110'
                    : isAnswered
                    ? 'bg-green-100 text-green-700 border border-green-300'
                    : 'bg-gray-100 text-gray-500 border border-gray-200 hover:bg-gray-200'
                }`}
              >
                {index + 1}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
